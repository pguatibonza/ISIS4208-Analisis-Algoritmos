El programa se ejecuta desde el archivo App.java. El archivo de entrada está en la carpeta input y se debe llamar input.txt. Al final de la ejecución se crea el archivo output.txt en la carpeta output.

El formato del archivo input.txt es:

n=[cantidad de nodos]
[origen,destino,capacidad]
...

El formato del archivo output.txt es:

Desde [origen] hasta [destino] con flujo [flujo actual] de capacidad [capacidad total]
...
Flujo total: [Flujo total que llega al destino]
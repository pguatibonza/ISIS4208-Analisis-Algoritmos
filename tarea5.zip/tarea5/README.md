# Ejecución del programa

## Generador de polinomios

Se debe ejecutar el archivo generator.java y por consola le pedirá el grado del polinomio a generar (ej. 20) al finalizar. Quedará el polinomio generado en la ruta input/input.txt

## Ejecución de métodos

Se debe ejecutar el archivo App.java y por consola le pedirá el método a ejecutar (1 para el método directo y 2 para el método FFT). Luego, mostrará en consola el tiempo de ejecución, el polinomio y guardará dicho polinomio en output/output[MetodoUsado].txt